﻿using ChatOnlne.Entity;
using ChatOnlne.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ChatOnlne.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessageController : ControllerBase
    {
        private readonly MyDBContext _context;
        public MessageController(MyDBContext context)
        {
            _context = context;
        }

        // GET: api/<MessageController>
        [HttpGet]
        public IActionResult GetAll()
        {
            var listMSG = _context.message.ToList();
            return Ok(listMSG);
        }

        // GET api/<MessageController>/5
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                var MSG_Id = _context.message.SingleOrDefault(x => x.Id == id);
                if (MSG_Id != null)
                {
                    return Ok(MSG_Id);
                }
                return NotFound(); ;
            }
            catch
            {
                return BadRequest();
            }
        }

        // POST api/<MessageController>
        [HttpPost]
        public IActionResult Post(MessageModel model)
        {
            try
            {
                var MSG = new Message()
                {
                    Content = model.Content,

                };

                var account = new Account()
                {
                    CodeUser = model.account.CodeUser // Trường "codeuser" từ MessageModel
                };

                MSG.account = account;

                _context.message.Add(MSG);
                _context.SaveChanges();
                return Ok(MSG);
            }
            catch
            {
                return BadRequest();
            }
        }

        // PUT api/<MessageController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, MessageModel model)
        {
            try
            {
                var MSG_Id = _context.message.SingleOrDefault(x => x.Id == id);
                if (MSG_Id != null)
                {
                    MSG_Id.Content = model.Content;
                    MSG_Id.account.CodeUser = model.account.CodeUser;
                    _context.SaveChanges();
                    return Ok(MSG_Id);
                }
                return NotFound();
            }
            catch
            {
                return BadRequest();
            }
        }

        // DELETE api/<MessageController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var MSG_Id = _context.message.SingleOrDefault(x => x.Id == id);
                if (MSG_Id != null)
                {
                    _context.Remove(MSG_Id);
                    _context.SaveChanges();
                    return Ok(new
                    {
                        success = true,
                        Data = _context.message.ToList()
                    });
                }
                return NotFound();
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
