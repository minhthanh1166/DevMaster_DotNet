﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChatOnlne.Entity
{
    [Table("Account")]
    public class Account
    {
        [Key]
        public Guid CodeUser { get; set; }
        [MaxLength(50)]
        public string Name { get; set; }
        [MaxLength(70)]
        public string Email { get; set; }
        [MaxLength(50)]
        [Required]
        public string UserName { get; set; }
        [MaxLength(50)]
        public string Password { get; set; }
        public ICollection<Message> messages { get; set; }
    }
}
