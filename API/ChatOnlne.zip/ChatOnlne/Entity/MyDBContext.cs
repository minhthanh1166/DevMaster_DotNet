﻿using Microsoft.EntityFrameworkCore;

namespace ChatOnlne.Entity
{
    public class MyDBContext : DbContext
    {
        public MyDBContext(DbContextOptions options) : base(options) { }

        #region DbSet
        public virtual DbSet<Account> account { get; set; }
        public virtual DbSet<Message> message { get; set; }

        #endregion
    }
}
