﻿using System.ComponentModel.DataAnnotations;

namespace ChatOnlne.Models
{
    public class AccountModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        [Required]
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
