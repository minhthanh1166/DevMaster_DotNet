﻿using ChatOnlne.Entity;

namespace ChatOnlne.Models
{
    public class MessageModel
    {
        public string Content { get; set; }
        public Account account { get; set; }
    }
}
